﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trening2
{
    class Silownia: Aktywnosc
    {

        private string[] nazwyUrzadzen;
        public Silownia(string[] nazwyUrzadzen, int puls)
        {
            this.puls = puls;
            this.nazwyUrzadzen = nazwyUrzadzen;

        }

        public override string ToString()
        {
            string tekst = "";
            for (int i = 1; i < nazwyUrzadzen.Length; i++)
            {
                tekst += $"\n\t -" + nazwyUrzadzen[i] ;
            }
            return string.Format("Siłownia tętno: " + puls + $" \n\t Nazwy urządzeń: " + tekst);
        }

    }
}

