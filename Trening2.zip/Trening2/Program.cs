﻿using System;

namespace Trening2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Stworzenie pojedynczych aktywnosci
            Bieganie bieganie1 = new Bieganie(10, 70);
            Silownia silownia1 = new Silownia(
                new string[] { "ławka dwustronna", "maszyna na mięśnie czworogłowe", "kołyska AB" }, 85);

            // Stworzenie tablicy aktywnosci
            Aktywnosc[] aktywnosci1 = new Aktywnosc[]
            {
                    bieganie1,
                    silownia1,
                    new Bieganie(10, 70),
                    new Silownia(new string[] {"maszyna na mięśnie czworogłowe"}, 85),
                    new Silownia(new string[] {"kołyska AB", "maszyna na mięśnie czworogłowe"}, 85),
                    new Bieganie(10, 70),
            };

            // Stworzenie osoby ćwiczącej
            Cwiczacy cw1 = new Cwiczacy("Michal1");
            // Dodanie kolejnych aktywności
            for (int i = 0; i < aktywnosci1.Length; i++)
            {
                cw1.DodajAktywnosc(aktywnosci1[i]);
            }
            // lub dodanie wszystkich na raz
            cw1.DodajAktywnosc(aktywnosci1);
            // Wyświetlenie
            cw1.WyswietlAktywnosc();

        }
    }
}
