﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trening2
{
    class Bieganie: Aktywnosc
    {
        private double dystans;
        public Bieganie(double dystans, int puls)
        {
            this.puls = puls;
            this.dystans = dystans;
        }
        public override string ToString()
        {
            return string.Format("Bieganie dystans: " + dystans + " tętno: " + puls);

        }
    }
}

