﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trening2
{
    class Cwiczacy
    {
        private readonly string imie;
        private readonly Aktywnosc[] aktywnosci;

        public Cwiczacy(string imie)
        {
            this.imie = imie;
            aktywnosci = new Aktywnosc[10];
        }

        public void DodajAktywnosc(Aktywnosc aktywnosc)
        {
            for (int i = 0; i <= aktywnosci.Length; i++)
            {
                if (aktywnosci[i] == null)
                {
                    aktywnosci[i] = aktywnosc;
                    break;
                }
            }
        }

        public void DodajAktywnosc(Aktywnosc[] aktywnosci)
        {
            if (this.aktywnosci.Length == aktywnosci.Length)
            {
                for (int i = 0; i <= aktywnosci.Length; i++)
                {
                    this.aktywnosci[i] = aktywnosci[i];
                }
            }
        }

        public void WyswietlAktywnosc()
        {
            double sumaPulse = 0;
            double licznik = 0;
            Console.WriteLine("Imię: " + imie);
            for (int i = 1; i < aktywnosci.Length; i++)
            {
                if (aktywnosci[i] != null)
                {
                    Console.WriteLine(i + ". " + aktywnosci[i].ToString());
                    sumaPulse += aktywnosci[i].Puls;
                    licznik++;
                }

            }
            double sredniaPuls = sumaPulse / licznik;
            Console.WriteLine("Średnia wartość tętna: " + sredniaPuls);
        }

    }
}

