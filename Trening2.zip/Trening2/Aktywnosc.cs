﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trening2
{
    class Aktywnosc
    {
        protected int puls;
        public int Puls
        {
            get{return puls;}
        }
    }
}
